import * as THREE from 'three';
import './style.css';

const mount = document.querySelector('#game');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9fc4d8);
scene.fog = new THREE.Fog(0x9fc4d8, 120, 320);

const camera = new THREE.PerspectiveCamera(62, innerWidth / innerHeight, 0.1, 700);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;
mount.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xe7f4ff, 0x526047, 2));
const sun = new THREE.DirectionalLight(0xfff0d8, 3);
sun.position.set(-60, 90, 55);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -120; sun.shadow.camera.right = 120;
sun.shadow.camera.top = 120; sun.shadow.camera.bottom = -120;
scene.add(sun);

const material = (color, roughness=.7, metalness=0) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness });
const grassMat = material(0x47734a);
const roadMat = material(0x252a30, .95);
const curbRed = material(0xc51e25);
const curbWhite = material(0xf0f0e9);
const rubber = material(0x111820, .45, .25);

const ground = new THREE.Mesh(new THREE.PlaneGeometry(600, 600), grassMat);
ground.rotation.x = -Math.PI/2;
ground.position.y = -.3;
ground.receiveShadow = true;
scene.add(ground);

const RX = 76, RZ = 48, ROAD_WIDTH = 15, SEGMENTS = 400;
const pointOnTrack = (t, offset=0) =>
  new THREE.Vector3((RX+offset)*Math.cos(t), 0, (RZ+offset)*Math.sin(t));

function makeRibbon() {
  const positions = [], indices = [];
  for (let i=0; i<=SEGMENTS; i++) {
    const t = i/SEGMENTS*Math.PI*2;
    const center = pointOnTrack(t);
    const tangent = new THREE.Vector3(-RX*Math.sin(t),0,RZ*Math.cos(t)).normalize();
    const side = new THREE.Vector3(tangent.z,0,-tangent.x);
    for (const offset of [-ROAD_WIDTH/2, ROAD_WIDTH/2]) {
      const p = center.clone().addScaledVector(side, offset);
      positions.push(p.x, .02, p.z);
    }
    if (i<SEGMENTS) {
      const a=i*2;
      indices.push(a,a+1,a+2, a+1,a+3,a+2);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions,3));
  g.setIndex(indices); g.computeVertexNormals();
  const mesh = new THREE.Mesh(g,roadMat);
  mesh.receiveShadow = true; scene.add(mesh);
}
makeRibbon();

function addBoundary(offset, color, radius=.3) {
  const points=[];
  for(let i=0;i<SEGMENTS;i++) points.push(pointOnTrack(i/SEGMENTS*Math.PI*2,offset));
  const curve=new THREE.CatmullRomCurve3(points,true);
  const mesh=new THREE.Mesh(new THREE.TubeGeometry(curve,500,radius,8,true),color);
  scene.add(mesh);
}
addBoundary(-ROAD_WIDTH/2,curbWhite);
addBoundary( ROAD_WIDTH/2,curbWhite);

for (const side of [-1,1]) {
  for(let i=0;i<120;i++) {
    const t=i/120*Math.PI*2;
    const p=pointOnTrack(t,side*(ROAD_WIDTH/2+.55));
    const curb=new THREE.Mesh(new THREE.BoxGeometry(2.1,.16,1),i%2?curbWhite:curbRed);
    curb.position.set(p.x,.08,p.z); curb.rotation.y=-t; scene.add(curb);
  }
}

const treeTrunk=material(0x59402a), treeTop=material(0x2d633a);
for(let i=0;i<70;i++){
  const a=i*2.399, r=95+(i%8)*5;
  const x=Math.cos(a)*r, z=Math.sin(a)*r*.68;
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.22,.35,2.8,7),treeTrunk);
  trunk.position.set(x,1.1,z); scene.add(trunk);
  const crown=new THREE.Mesh(new THREE.ConeGeometry(2.1,5.5,8),treeTop);
  crown.position.set(x,4.5,z); crown.castShadow=true; scene.add(crown);
}

const standMat=material(0x596570);
for(let i=0;i<18;i++){
  const step=new THREE.Mesh(new THREE.BoxGeometry(4,1+i*.14,12),standMat);
  step.position.set(-8+i*4,.1,-68); scene.add(step);
}

function createCar(color) {
  const group=new THREE.Group();
  const paint=material(color,.25,.65);
  const glass=new THREE.MeshStandardMaterial({color:0x172c3a,metalness:.5,roughness:.18});
  const body=new THREE.Mesh(new THREE.BoxGeometry(2.2,.62,4.6),paint);
  body.position.y=.72; body.castShadow=true; group.add(body);
  const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.62,.7,1.9),glass);
  cabin.position.set(0,1.2,.1); cabin.castShadow=true; group.add(cabin);
  const roof=new THREE.Mesh(new THREE.BoxGeometry(1.5,.12,1.2),paint);
  roof.position.set(0,1.59,.1); group.add(roof);
  for(const x of [-1.15,1.15]) for(const z of [-1.5,1.5]) {
    const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.42,.42,.28,20),rubber);
    wheel.rotation.z=Math.PI/2; wheel.position.set(x,.45,z); wheel.castShadow=true; group.add(wheel);
  }
  const spoiler=new THREE.Mesh(new THREE.BoxGeometry(2.4,.12,.4),rubber);
  spoiler.position.set(0,1.28,2.05); group.add(spoiler);
  return group;
}

const player=createCar(0xc91520); scene.add(player);
const rivals=[0x1674cf,0xf2c32b,0xe8e8e8].map((color,i)=>{
  const mesh=createCar(color); scene.add(mesh);
  return {mesh, progress:(i+1)*.035, pace:.065+i*.004, laps:0};
});

function setCarOnTrack(mesh,t,lane=0) {
  const p=pointOnTrack(t,lane);
  mesh.position.set(p.x,0,p.z);
  mesh.rotation.y=-Math.atan2(-RZ*Math.cos(t),-RX*Math.sin(t));
}
const keys={};
addEventListener('keydown',e=>{
  keys[e.key.toLowerCase()]=true;
  if(e.key===' ') resetRace();
  if(e.key.toLowerCase()==='c') cockpit=!cockpit;
});
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);

function holdButton(id,key) {
  const el=document.getElementById(id);
  el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture(e.pointerId);keys[key]=true;});
  for(const event of ['pointerup','pointercancel','lostpointercapture'])
    el.addEventListener(event,()=>keys[key]=false);
}
holdButton('left','left'); holdButton('right','right');
holdButton('gas','gas'); holdButton('brake','brake');

let angle=0, speed=0, playerLaps=0, elapsed=0;
let running=false, finished=false, cockpit=false, previous=performance.now();

function resetRace(){
  angle=0; speed=0; playerLaps=0; elapsed=0; finished=false; running=true;
  rivals.forEach((r,i)=>{r.progress=(i+1)*.035;r.laps=0;});
  document.querySelector('#center-message').textContent='';
  setCarOnTrack(player,0);
}
document.querySelector('#start').addEventListener('click',()=>{
  document.querySelector('#start-screen').style.display='none';
  resetRace();
});

function clock(s){
  const m=Math.floor(s/60), sec=Math.floor(s%60);
  return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
}

function frame(now){
  requestAnimationFrame(frame);
  const dt=Math.min((now-previous)/1000,.04); previous=now;

  if(running && !finished){
    elapsed+=dt;
    const steer=(keys.right||keys.d||keys.arrowright?1:0)-
                (keys.left||keys.a||keys.arrowleft?1:0);
    const accelerating=keys.gas||keys.w||keys.arrowup;
    const braking=keys.brake||keys.s||keys.arrowdown;
    speed += (accelerating?.78:0)*dt;
    speed -= (braking?2.4:.18)*dt;
    speed=Math.max(0,Math.min(speed,1.0));
    angle += speed*dt*.18 + steer*dt*(.16+speed*.55);

    if(angle>=Math.PI*2){
      angle-=Math.PI*2; playerLaps++;
      if(playerLaps>=3){
        finished=true;
        document.querySelector('#center-message').innerHTML='ZIEL!<small>LEERTASTE FÜR NEUSTART</small>';
      }
    }
    setCarOnTrack(player,angle);
    player.rotation.y += steer*-.13;

    rivals.forEach(r=>{
      r.progress+=r.pace*dt;
      if(r.progress>=Math.PI*2){r.progress-=Math.PI*2;r.laps++;}
      setCarOnTrack(r.mesh,r.progress,0);
    });
  }

  const forward=new THREE.Vector3(Math.sin(player.rotation.y),0,Math.cos(player.rotation.y));
  if(cockpit){
    camera.position.copy(player.position).add(new THREE.Vector3(0,1.8,0)).addScaledVector(forward,-.2);
    camera.lookAt(player.position.clone().addScaledVector(forward,22).add(new THREE.Vector3(0,1.5,0)));
  } else {
    const desired=player.position.clone().addScaledVector(forward,-10).add(new THREE.Vector3(0,5,0));
    camera.position.lerp(desired,.1);
    camera.lookAt(player.position.clone().add(new THREE.Vector3(0,1,0)));
  }

  document.querySelector('#speed').textContent=Math.round(speed*300);
  document.querySelector('#lap').textContent=`${Math.min(playerLaps+1,3)}/3`;
  document.querySelector('#time').textContent=clock(elapsed);
  renderer.render(scene,camera);
}
setCarOnTrack(player,0);
rivals.forEach((r,i)=>setCarOnTrack(r.mesh,r.progress,[-3.5,0,3.5][i]));
camera.position.set(0,13,105); camera.lookAt(0,0,0);
requestAnimationFrame(frame);

addEventListener('resize',()=>{
  camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
});
