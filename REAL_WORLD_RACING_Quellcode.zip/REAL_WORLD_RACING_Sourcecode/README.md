# REAL WORLD RACING – Quellcode

Dies ist ein echtes, editierbares Web-Spielprojekt auf Basis von JavaScript und Three.js.

## Voraussetzungen
- Node.js 18 oder neuer
- Internetverbindung für die Installation der Pakete

## Start auf PC oder Mac
1. ZIP entpacken.
2. Im Projektordner ein Terminal öffnen.
3. `npm install` ausführen.
4. `npm run dev` ausführen.
5. Die angezeigte lokale Adresse im Browser öffnen.

## Produktionsversion bauen
`npm run build` erstellt den Ordner `dist`.

## iPad-Hinweis
Eine HTML-/JavaScript-Web-App muss über einen Webserver mit HTTPS ausgeliefert werden, damit sie auf dem iPad zuverlässig im Browser läuft. Die Dateien allein in der iPad-Dateien-Vorschau auszuführen, funktioniert nicht zuverlässig. Du kannst das Projekt z. B. auf einem Webhosting oder einer statischen Hosting-Plattform veröffentlichen und dann die HTTPS-Adresse in Safari öffnen.

## Steuerung
- WASD oder Pfeiltasten: fahren/lenken
- C: Cockpit-/Verfolgerkamera wechseln
- Leertaste: Rennen neu starten
- Touch: Pfeile, Gas und Bremse auf dem Bildschirm

## Aktueller Umfang
Spielbarer 3D-Einzelspieler-Prototyp mit Rennstrecke, einem Spielerauto, drei einfachen KI-Fahrzeugen, Rundenanzeige und Timer.

## Noch nicht enthalten
- echter Online-Mehrspieler (benötigt Server, Netzwerkprotokoll und Synchronisierung)
- fertige Fahrzeugmodelle, Cockpit-Instrumente und lizenzierte Fahrzeugmarken
- realistische Motor-/Reifensounds und Schadensmodell
- App-Store-/Play-Store-Pakete
